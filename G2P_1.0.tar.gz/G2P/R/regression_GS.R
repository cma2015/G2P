####################################################### Fit regression model ###################################################
### models from BGLR package
##model: BayesA (Scaled-t prior), BayesB (point of mass at zero + scaled-t slab), BayesC, Bayesian LASSO (BL), Bayesian Ridge Regression(BR; (Gaussian prior), equivalent to G-BLUP), RKHS
trainedPredictModel_BGLR <- function( trainedMarkerMat, trainedPhenVec, modelMethods,  nIter = 7000, burnIn = 500, thin = 5, 
                                      saveAt = "", S0 = NULL, df0 =5, R2 = 0.5, weights = NULL,
                                      verbose = FALSE, rmExistingFiles = TRUE, groups=NULL){
  
  checkModel <- modelMethods %in% c("BayesA", "BayesB", "BayesC", "BL", "BRR", "RKHS")
  if( ! checkModel ) {
    stop("Error: not defined model!")
  }
  
  BGLRModel.fit <- NULL
  tryCatch({
    if( modelMethods != "RKHS") {
      BGLRModel.fit <- BGLR( y=trainedPhenVec, ETA=list(list(X=trainedMarkerMat, model= modelMethods)),  nIter = nIter, burnIn = burnIn, thin = thin, 
                             saveAt = saveAt, S0 = S0, df0 = df0, R2 = R2, weights = weights,
                             verbose = verbose, rmExistingFiles = rmExistingFiles, groups = groups )
      
      
    }else{
      # Computing the genomic relationship matrix
      X <-scale(x = trainedMarkerMat,center=TRUE,scale=TRUE)
      G <-tcrossprod(X)/ncol(X)
      
      BGLRModel.fit <- BGLR( y=trainedPhenVec, ETA=list(list(K=G, model= modelMethods)),  nIter = nIter, burnIn = burnIn, thin = thin, 
                             saveAt = saveAt, S0 = S0, df0 = df0, R2 = R2, weights = weights,
                             verbose = verbose, rmExistingFiles = rmExistingFiles, groups = groups )
      
    }
  }, error=function(e){
    gc(verbose=F)
    BGLRModel.fit <- NULL
  }, warning=function(w){
    gc(verbose=F)
    BGLRModel.fit <- NULL
  }); gc(verbose=F)
  
  return(BGLRModel.fit)
}
################# 
trainModel_RRBLUP <- function( markerMat, phenVec ){
  phen_answer<-mixed.solve(phenVec, Z=markerMat, K=NULL, SE = FALSE, return.Hinv=FALSE)
  beta <- phen_answer$beta
  phD <- phen_answer$u
  e <- as.matrix(phD)
  return( list(beta = beta, e = e, phD = phD) ) 
}




#' @title Fit Regression Model  
#' 
#' @description This function can fit several regression models of genomic selection such as BayesA, BayesB,BayesC,BRR(BayesBayesian Ridge Regression),BL(Bayesian LASSO),RHKS(Bayesian Reproducing Kernel Hilbert Space),etc.
#' @param markers  (numeric)a matrix, each row is the each individual's SNP genotypes informations.Genotypes should be coded as {0,1,2}or{-1,0,1};0(-1) represent AA(homozygote),2(1) represent BB(homozygote) and 1(0) represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param pheVal  (numeric)the phenotype value of each individual.
#' @param modelMethods  the model to fit."BayesA", "BayesB", "BayesC", "BL", "BRR","rrBLUP","LASSO","SPLS","RKHS".
#' @param nIter,burnIn,thin  (integer) the number of iterations, burn-in and thinning,default nIter 7000,burnIn 500,thin 5.
#' @param saveAt  (string) this may include a path and a pre-fix that will be added to the name of the files that are saved as the program runs,default "".
#' @param S0,df0  (numeric) The scale parameter for the scaled inverse-chi squared prior assigned to the residual variance, only used with Gaussian outcomes. In the parameterization of the scaled-inverse chi square in BGLR the expected values is S0/(df0-2). The default value for the df parameter is 5. If the scale is not specified a value is calculated so that the prior mode of the residual variance equals var(y)*R2 (see below). For further details see the vignettes in the package or http://genomics.cimmyt.org/BGLR-extdoc.pdf.Default S0 NULL,df0 5.
#' @param R2  (numeric, 0<R2<1) The proportion of variance that one expects, a priori, to be explained by the regression. Only used if the hyper-parameters are not specified; if that is the case, internaly, hyper-paramters are set so that the prior modes are consistent with the variance partition specified by R2 and the prior distribution is relatively flat at the mode. For further details see the vignettes in the package or http://genomics.cimmyt.org/BGLR-extdoc.pdf.Defult 0.5
#' @param weights  (numeric, n) a vector of weights, may be NULL. If weights is not NULL, the residual variance of each data-point is set to be proportional to the square of the weight. Only used with Gaussian outcomes.
#' @param verbose  (logical) if TRUE the iteration history is printed, default FALSE.
#' @param rmExistingFiles  (logical) if TRUE removes existing output files from previous runs, default TRUE.
#' @param groups  (factor) a vector of the same length of y that associates observations with groups, each group will have an associated variance component for the error term.
#' @param ntree  RandomForest parameter:Number of trees to grow. This should not be set to too small a number, to ensure that every input row gets predicted at least a few times.Defualt 500.
#' @param importance  RandomForest parameter:Should importance of predictors be assessed? Defualt FALSE.
#' @param K  Number of hidden components
#' @param eta	 Thresholding parameter. eta should be between 0 and 1.
#' @param select  PLS algorithm for variable selection. Alternatives are "pls2" or "simpls". Default is "pls2"
#' @param fit	 PLS algorithm for model fitting. Alternatives are "kernelpls", "widekernelpls", "simpls", or "oscorespls". Default is "simpls".
#' @param scale.x	 Scale predictors by dividing each predictor variable by its sample standard deviation?
#' @param scale.y  Scale responses by dividing each response variable by its sample standard deviation?
#' @param eps  An effective zero. Default is 1e-4
#' @param maxstep  Maximum number of iterations when fitting direction vectors. Default is 100.
#' @param trace  Print out the progress of variable selection?
#' @param alpha  The elasticnet mixing parameter, with 0≤α≤ 1.Detail in glmnet.
#' @param ... arguments passed to or from other package.
#' @return  
#' A regression model which is enable to predict.
#' @author Chuang Ma  , Qian Cheng , Zhixu Qiu , Jie Song
#' @keywords regression model, BayesA, BayesB, BayesC, BRR, BL, RKHS, RR, SVR, RFR, LASSO, SPLS
#' @export
#' @examples
#' \dontrun{
#' ## Load example data ##
#' data(GYSS)
#'
#' ## Fit rrBLUP model ##
#' rrBLUP_model <- GSReModel(markers = Markers,pheVal = phenotype,modelMethods = "rrBLUP")
#' }

GSReModel <- function(markers, pheVal, modelMethods, nIter = 7000, burnIn = 500, thin = 5, 
                      saveAt = "", S0 = NULL, df0 =5, R2 = 0.5, weights = NULL,
                      verbose = FALSE, rmExistingFiles = TRUE, groups=NULL, ntree = 500, importance = FALSE,
                      K = 8, eta = 0.7, select = "pls2", fit = "simples", scale.x = FALSE, scale.y = FALSE, eps = 1e-4, trace = FALSE, maxstep = 100,
                      alpha = 1,...){  

  checkModel <- modelMethods %in% c("BayesA", "BayesB", "BayesC", "BL", "BRR", "RKHS","rrBLUP","LASSO","SPLS")
  if( ! checkModel ) {
    stop("Error: not defined models for implementing GSReModel!")
  }
  if (modelMethods %in% c("BayesA", "BayesB", "BayesC", "BL", "BRR", "RKHS")){
    BGLRmethods <- modelMethods
    modelMethods <- "BGLRModel"
  }
  
  
  switch(modelMethods,
         BGLRModel  = trainedPredictModel_BGLR(trainedMarkerMat = markers, trainedPhenVec = pheVal, modelMethods = BGLRmethods ,nIter = nIter, burnIn = burnIn, thin = thin, 
                                               saveAt = saveAt, S0 = S0, df0 = df0, R2 = R2, weights = weights,verbose = verbose, rmExistingFiles = rmExistingFiles, groups=groups),
         rrBLUP  = trainModel_RRBLUP(markerMat = markers, phenVec = pheVal),
         LASSO = trainModel_LASSO(markers,pheVal,alpha = alpha),
         SPLS = trainModel_spls(markers,pheVal,K = K,eta = eta,select = select,fit = fit,scale.x = scale.x,scale.y = scale.y,eps = eps,trace = trace,maxstep = maxstep)
  )
  
}


################################  LASSO ##############################

trainModel_LASSO <- function(markers,pheVal,alpha = 1){
#glmnet fits a lasso model when we specify that alpha=1
	LASSO.fit <- glmnet(y=pheVal,x=markers,alpha=1)
#cv.glmnet finds the lambda value such that the the cvm value is the minimum
	cv <- cv.glmnet(y = pheVal, x=markers)
	LASSO_Res <- list(LASSO.fit = LASSO.fit,cv = cv)
	LASSO_Res
}

############################### spls #################################
trainModel_spls <- function(markers,pheVal,K = 8,eta = 0.7,select = "pls2",fit = "simples",scale.x = FALSE,scale.y = FALSE,eps = 1e-4,trace = FALSE, maxstep = 100, ...){
  f <- spls(markers,pheVal,K = K,eta = eta,select = select,fit = fit,scale.x =scale.x,scale.y = scale.y,eps = eps,trace = trace )
  f
}
