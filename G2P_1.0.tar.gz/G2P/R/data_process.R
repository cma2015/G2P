# ######################### get system time for seed and then generate random index ###########
# title Generate Random Seed
# description This funcation is appplied for generating random seed with current system time
# return  
# (numeric) A random seed 
# author Chuang Ma  , Qian Cheng , Zhixu Qiu ,Wenlong Ma

randomSeed <- function() {
  curtime <- format(Sys.time(), "%H:%M:%OS4")
  XXX <- unlist(strsplit(curtime, ":"))
  curtimeidx <- (as.numeric(XXX[1])*3600 + as.numeric(XXX[2])*60 + as.numeric(XXX[3]))*10000
  curtimeidx
}

########################## load example data ###########################
#' @name GYSS
#' @title Example Data for G2P
#' @description
#' The data of maize yield under drought stressed.(SNP genotypes informations) 
#'  \itemize{
#'  \item{Markers} {A numeric matrix, each row is the each individual's SNP genotypes informations.}
#'  \item{phenotype} {The real phenotype Value of each individual.}
#'  }
#' @author Chuang Ma  , Qian Cheng , Zhixu Qiu , Jie Song
#' @keywords datasets
#' @docType data
#' @examples
#' \dontrun{
#' ##load maize yield datasets
#' data(GYSS)
#' }
NULL

########################## marker data ###########################
#' @name Markers
#' @title Example Data for G2P
#' @description
#' A numeric matrix.
#'  \itemize{
#'  \item{each row represents each sample}
#'  \item{each column represents each SNP locus}
#'  }
#' @author Chuang Ma, Qian Cheng, Zhixu Qiu, Jie Song
#' @keywords datasets
#' @docType data
#' @format matrix
NULL

########################## phenotype data ###########################
#' @name phenotype
#' @title Example Data for G2P
#' @description
#' The real phenotype Value of each individual
#' @author Chuang Ma  , Qian Cheng , Zhixu Qiu , Jie Song
#' @keywords data , phenotype value
#' @docType data
#' @format vector
NULL

########### generated positive and negative samples for training####################
#' @title Generate Positive and Negative Samples for Training 
#' @description This function can be use to generate positive and negative samples for training.The positive samples represent the excellent individuals which's breeding values we expect to obtain in your research.And the negative samples represent the lower breeding values of individuals. 
#' @param pheVal  (numeric)the breeding values of each individual.
#' @param posPercentage  (numeric,1 > posPercentage > 0)the percentage of positive samples for a trait in training groups.
#' @param BestIndividuals  It is a position that the best individuals (positive samples) in a training group, according to the breeding values of a training group's trait.
#'                         if the trait was yield,flowering or disease resistance,and  male flowering time to female flowering time,it is "top"(default), "buttom",and "middle" of the breeding values, respectively.
#' @return  
#' 
#' A list of row number of positive and negative samples
#' $posSampleIndex Index of positive samples
#' $negSampleIndex  Index of negative samples
#' 
#' @author Chuang Ma, Qian Cheng, Zhixu Qiu, Jie Song
#' @keywords positive , negative 
#' @export
#' @examples
#' \dontrun{
#' data(GYSS)
#' ## percentage of positive samples is 0.4 ##
#' sampleCly <- sampleClassify(phenotype, posPercentage = 0.4, BestIndividuals = "top")
#' } 

sampleClassify <- function(pheVal, posPercentage = 0.4, BestIndividuals = c("top", "middle", "buttom")){
  trainSampleSize <- length(pheVal)
  posSampleSize <- round( posPercentage*trainSampleSize )
  
  if( BestIndividuals == "top" ){
    trainPhenOrder <- order( pheVal, decreasing = TRUE )
  }else if( BestIndividuals == "buttom" ){
    trainPhenOrder <- order( pheVal, decreasing = FALSE )   
  }else if( BestIndividuals == "middle"){
    trainPhenOrder <- order( abs(pheVal), decreasing = FALSE ) 
  }
  posIdx <- trainPhenOrder[1:posSampleSize]
  negIdx <- setdiff( c(1:trainSampleSize), posIdx )
  
  res <- list( posSampleIndex = posIdx, negSampleIndex = negIdx )
  res
}


########################generate train idx and test idx ##########################
#' @title Generate Sample Indices for Training Sets and Testing Sets
#' @description  This function generates indices for samples in training and testing sets for performing the N-fold cross validation experiment.
#' @param sampleNum  The number of samples needed to be partitioned into training and testing sets.
#' @param cross  The fold of cross validation.
#' @param seed  An integer used as the seed for data partition. The default value is 1.
#' @param randomSeed  Logical variable, default FALSE.
#' @return 
#' A list and each element including $trainIdx $testIdx and $cvIdx
#' 
#' $trainIdx  The index of training samples.
#' 
#' $testIdx   The index of testing samples.
#' 
#' $cvIdx     The cross validation index.
#' @author Chuang Ma, Zhixu Qiu, Qian Cheng, Wenlong Ma
#' @export
#' @examples
#' \dontrun{
#' ## Load example data ##
#' data(GYSS)
#' ## leave-one out cross validation
#' a <- cvSampleIndex(sampleNum = nrow(Markers), cross = nrow(Markers), seed = 1)
#' 
#' ## 5-fold cross validation
#' b <- cvSampleIndex(sampleNum = nrow(Markers), cross = 5, seed = 1)
#' }

##get sample idx for training and testing
cvSampleIndex <- function( sampleNum, cross = 5, seed = 1,randomSeed = FALSE ) {
  if(randomSeed == TRUE){
    seed <- randomSeed()
  }
  cv <- cross
  resList <- list()
  
  # leave-one-out
  if( cv == sampleNum ){
    vec <- 1:sampleNum
    for( i in 1:sampleNum ){
      resList[[i]] <- list( trainIdx = vec[-i], testIdx = i, cvIdx = i)
    }
  }else {
    #random samples 
    set.seed(seed)
    index <- sample(1:sampleNum, sampleNum, replace = FALSE )
    step = floor( sampleNum/cv )
    
    start <- NULL
    end <- NULL
    train_sampleNums <- rep(0, cv)
    for( i in c(1:cv) ) {
      start <- step*(i-1) + 1
      end <- start + step - 1
      if( i == cv ) 
        end <- sampleNum
      
      testIdx <- index[start:end]
      trainIdx <- index[-c(start:end)]
      resList[[i]] <- list( trainIdx = trainIdx, testIdx = testIdx, cvIdx = i)
    }
  }
  names(resList) <- paste0("cv",1:cross)
  resList
}
