
###############################Fit a machine learning  model ############################


#' @title Fit machine learning model  
#' 
#' @description This function can fit several machine learning models of genomic selection such as svm (support vector machine),ramdomforest
#' @param markers  (numeric)a matrix, each row is the each individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represent AA(homozygote),2 represent BB(homozygote) and 1 represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param pheVal  (numeric)the phenotype value of each individual.
#' @param posPercentage  (numeric,1 > posPercentage > 0)the percentage of positive samples for a trait in training groups.
#' @param  BestIndividuals  It is a position that the best individuals (positive samples) in a training group, according to the breeding values of a training group's trait.
#'                          if the trait was yield,flowering or disease resistance,and  male flowering time to female flowering time,it is "top"(default), "buttom",and "middle" of the breeding values, respectively.
#' @param modelMethods  the methods is built genomic selection model. "SVR" or "SVC  represent a regression or classification model build by using svm, and also
#'                      "RFR" or "RFC" is a ramdomforest methods to build a regression  or classification model
#' @param ntree  ramdomforest parameter (integer)Number of trees to grow. This should not be set to too small a number, to ensure that every input row gets predicted at least a few times,default 500.
#' @param nodesize	ramdomforest parameter Minimum size of terminal nodes. Setting this number larger causes smaller trees to be grown (and thus take less time). Note that the default values are different for classification (1) and regression (5).
#' @param kernel  svm parameter the kernel used in training and predicting. You might consider changing some of the following parameters, depending on the kernel type.(linear,polynomial,sigmoid,radial)Default radial
#' @param gamma  svm parameter parameter needed for all kernels except linear (default: 1/(data dimension))
#' @param cost  svm parameter cost of constraints violation (default: 2^(-9))-it is the 'C'-constant of the regularization term in the Lagrange formulation.
#' @return  
#' a machine model which is enable to predict
#' @author Chuang Ma, Qian Cheng, Zhixu Qiu, Jie Song
#' @keywords model, randomforest, svm
#' @export
#' @examples
#' \dontrun{
#' ## Load example data ##
#' data(GYSS)
#'
#' ## Fit RFR model ##
#' machine_model <- GSmachine(markers = Markers, pheVal = phenotype, modelMethods = "RFR")
#' 
#' ## Fit classification model(RFC) ##
#' machine_model <- GSmachine(markers = Markers, pheVal = phenotype, modelMethods = "RFC",
#'                            posPercentage = 0.4, ntree = 500)
#' }


GSmachine <- function(markers, pheVal, modelMethods ="SVC", posPercentage = 0.4, BestIndividuals = c("top"), ntree = 500,
	              nodesize = 1, kernel = c("linear"), gamma = 1, cost = 2^(-9)){

  if( !modelMethods%in% c("SVR","SVC","RFR","RFC") ) {
    stop("Error: not defined category")
  }
  if (modelMethods %in%  c("SVC","RFC")){
    posNegSampleList <- sampleClassify(pheVal = pheVal ,posPercentage = posPercentage ,BestIndividuals = BestIndividuals )
    markers <- markers[c(posNegSampleList$posSampleIndex,posNegSampleList$negSampleIndex),]
    pheVal <-  as.factor( c( rep("1", length(posNegSampleList$posSampleIndex)), rep("0", length(posNegSampleList$negSampleIndex)) ) )
  
  }
  
  if(modelMethods %in%  c("SVR","SVC")){
    modelMethods <- "svm"
  }
  
  if(modelMethods %in% c("RFR","RFC")){
    modelMethods <- "randomforest"
  }
  switch(modelMethods,
         svm = svm(x= markers, y = pheVal,kernel = kernel,cost=cost,gamma = gamma,probability = TRUE),
         randomforest = randomForest( x = markers, y = pheVal, ntree = ntree, importance = F,nodesize = nodesize))
}

