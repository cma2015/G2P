########################### the prediction of genomic selection ###########################

#' @title Prediction with Trained Model from Geomic Selection Model
#' 
#' @description This function is give the prediction score of a new GS data by using already model.
#' @param testMat  (numeric)a matrix, each row is the each testing sets or new GS data individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represent AA(homozygote),2 represent BB(homozygote) and 1 represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param modelMethods  (character)the type name of training model including "BayesA", "BayesB", "BayesC", "BL", "BRR", "RKHS","rrBLUP","SVC","SVR","RFC","RFR".
#' @param trainModel  The trained model.It's type must be similar whith modelMethods.
#' @param type  SPLS parameter,detail see package spls.
#' 
#' @return
#' a list:  
#' The prediction result of testing sets which predicted through already models
#' @author Chuang Ma  , Qian Cheng , Zhixu Qiu , Jie Song
#' @keywords model , predicttion
#' @export
#' @examples
#' \dontrun{
#' ## Load example data ##
#' data(GYSS)
#'
#' ## Fit rrBLUP model ##
#' rrBLUP_model <- GSReModel(markers = Markers, pheVal = phenotype, modelMethods = "rrBLUP")
#'
#' ## Predict 1-20 subset of all example data with already rrBLUP model ## 
#' res <- predictGS(testMat = Markers[1:20,], trainModel = rrBLUP_model, modelMethods = "rrBLUP")
#' }

predictGS <- function(testMat, trainModel, modelMethods = "SVC",type = "fit"){
  ########## check the methods of GS
  checkModel <- modelMethods %in% c("BayesA", "BayesB", "BayesC", "BL", "BRR", "RKHS","rrBLUP","SVR","SVC","RFR","RFC","LASSO","SPLS")
  if( ! checkModel ) {
    stop("Error: not defined models for implementing GS Model")
  }
  ####### 
  if (modelMethods %in% c("BayesA", "BayesB", "BayesC", "BL", "BRR", "RKHS")){
    Methods <- "BGLRModel"
  }else{
    Methods <- modelMethods
  }
  
  ####### check testset 
  if(!is.matrix(testMat)) {
    testMat <- rbind(testMat,testMat)
    testnum <- 1 
  }else{
    testnum <- nrow(testMat)
  }
  
  
  #############
  if (modelMethods %in% c("BayesA", "BayesB", "BayesC", "BL", "BRR", "RKHS","rrBLUP","SVR","RFR","LASSO","SPLS")){
    predresult <- switch(Methods,
                         BGLRModel = {mkr.effs <- as.numeric(trainModel$ETA[[1]]$b); testMat %*% mkr.effs},
                         rrBLUP = {pred_phenVec <-  testMat %*% trainModel$e; pred_phenVec[,1] + trainModel$beta },
                         SVR = predict( trainModel, testMat),
                         RFR = predict( object = trainModel,testMat ),
                         LASSO = pred_LASSO(trainModel,testMat),
                         SPLS = pred_SPLS(trainModel,testMat,type= type)
    )
  }
  else if (modelMethods %in% c("SVC","RFC")){
    predresult <- switch(modelMethods,
                         SVC = {obj_pred <- predict(trainModel,testMat, probability = TRUE); as.matrix(attr(obj_pred, "probabilities")[,"1"])},
                         RFC = predict(trainModel, testMat, type= "vote" )[,"1"])
  }
  predresult[1:testnum]
  
}


################### Modeling and predicting using RR ########################


#' @title Modeling and Predicting using ridge regression  
#' 
#' @description This function can fit ridge regression model and export the prediction value of testing sets. 
#' @param trainedMarkerMat  (numeric)a matrix, each row is the each training sets individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represent AA(homozygote),2 represent BB(homozygote) and 1 represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param trainedPheVal  (numeric)the phenotype Value of each individual.
#' @param predictMarkerMat  (numeric)a matrix, each row is the each testing sets individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represent AA(homozygote),2 represent BB(homozygote) and 1 represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param cpus  Number of cpu cores to use for calculations (only available in UNIX-like operating systems). The function detectCores in the R package parallel can be used to attempt to detect the number of CPUs in the machine that R is running, but not necessarily all the cores are available for the current user, because for example in multi-user systems it will depend on system policies. Further details can be found in the documentation for the parallel package,default 1.
#' @return  
#' a array of the result from ridge regression
#' @author Chuang Ma  , Qian Cheng , Zhixu Qiu , Jie Song
#' @keywords RR model predict
#' @export
#' @examples
#' \dontrun{
#' ## Not run: 
#' ## Load example data ##
#' data(GYSS)
#'
#' ## use RR model to modeling and predict ##
#' rr_Res <- RR.F2P(trainedMarkerMat = Markers, trainedPheVal = phenotype,
#'                  predictMarkerMat = Markers[1:10,], cpus = 1 )
#' }



###predicted model using ridge regression

RR.F2P <- function(trainedMarkerMat, trainedPheVal, predictMarkerMat, cpus = 1){
  yield_answer <- kinship.BLUP( y = trainedPheVal, G.train = trainedMarkerMat, G.pred= predictMarkerMat, K.method="RR", n.core = cpus)
  pred_yield_valid = yield_answer$g.pred
  pred_yield_valid
}

#' @title Modeling and predicting using Bayesian Regularization Neural Networks(BRNN)
#' 
#' @description This function can fit BRNN model and export the prediction value of testing sets. 
#' @param trainedMarkerMat  (numeric)a matrix, each row is the each training sets individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represent AA(homozygote),2 represent BB(homozygote) and 1 represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param trainedPheVal  (numeric)the phenotype Value of each individual.
#' @param predictMarkerMat  (numeric)a matrix, each row is the each testing sets individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represent AA(homozygote),2 represent BB(homozygote) and 1 represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param cpus  Number of cpu cores to be used for calculations (only available in UNIX-like operating systems). The function detectCores in the R package parallel can be used to attempt to detect the number of CPUs in the machine that R is running, but not necessarily all the cores are available for the current user, because for example in multi-user systems it will depend on system policies. Further details can be found in the documentation for the parallel package,default 1.
#' @param neurons  positive integer that indicates the number of neurons,defult 4.
#' @param epochs  positive integer, maximum number of epochs(iterations) to train, default 1000.
#' @param verbose logical, if TRUE will print iteration history.
#' @param ... Other parameters, details see package brnn
#' @return  
#' a array of the result from BRNN
#' @author Chuang Ma  , Qian Cheng , Zhixu Qiu , Jie Song
#' @keywords BRNN, model predict
#' @export
#' @examples
#' \dontrun{
#' ## Load example data ##
#' data(GYSS)
#'
#' ## use RR model to modeling and predict ##
#' BRNN_Res <- BRNN.F2P(trainedMarkerMat = Markers,trainedPheVal = phenotype,
#'                      predictMarkerMat = Markers[1:10,],cpus = 1 )
#' }

################### Modeling and predicting using BRNN#############################

BRNN.F2P <- function(trainedMarkerMat, trainedPheVal, predictMarkerMat, verbose=TRUE, neurons=4, epochs=1000, cpus = 1, ...){
  X<- rbind(trainedMarkerMat,predictMarkerMat)
  trainNum <- nrow(trainedMarkerMat)
  yTRN <- trainedPheVal
  n<-nrow(X) 
  p<-ncol(X)
  
  for(i in 1:ncol(X)){ (X[,i]<-X[,i]-mean(X[,i]))/sd(X[,i])}
  G<-tcrossprod(X)/ncol(X)
  trainedMarkerMat <- G[1:trainNum,]
  predictMarkerMat <- G[-(1:trainNum),]
  
  NN<-brnn(y=yTRN,x=trainedMarkerMat,neurons=neurons, epochs=epochs,verbose=verbose,cores = cpus)  
  yHatNN<- predict(NN, newdata = predictMarkerMat)
  yHatNN
}
####################### LASSO pred ######################### 
pred_LASSO <- function(trainModel,testMat){
  predict(object = trainModel$LASSO.fit,testMat,s = trainModel$cv$lambda.min)
}

###################### pls and spls###########################
pred_SPLS <- function(trainModel,testMat,type = "fit"){
  predict( trainModel,testMat,type=type )
}

#' @title Modeling and predicting using Reproducing Kernel Hilbert Space(RKHS).
#' 
#' @description This function can fit RKHS model and export the prediction value of testing sets. 
#' @param trainedMarkerMat  (numeric)a matrix, each row is the each training sets individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represent AA(homozygote),2 represent BB(homozygote) and 1 represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param trainedPheVal  (numeric)the phenotype Value of each individual.
#' @param predictMarkerMat  (numeric)a matrix, each row is the each testing sets individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represent AA(homozygote),2 represent BB(homozygote) and 1 represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param nIter,burnIn,thin  (integer) the number of iterations, burn-in and thinning,default nIter 7000,burnIn 500,thin 5.
#' @param saveAt  (string) this may include a path and a pre-fix that will be added to the name of the files that are saved as the program runs,default "".
#' @param S0,df0  (numeric) The scale parameter for the scaled inverse-chi squared prior assigned to the residual variance, only used with Gaussian outcomes. In the parameterization of the scaled-inverse chi square in BGLR the expected values is S0/(df0-2). The default value for the df parameter is 5. If the scale is not specified a value is calculated so that the prior mode of the residual variance equals var(y)*R2 (see below). For further details see the vignettes in the package or http://genomics.cimmyt.org/BGLR-extdoc.pdf.Default S0 NULL,df0 5.
#' @param R2  (numeric, 0<R2<1) The proportion of variance that one expects, a priori, to be explained by the regression. Only used if the hyper-parameters are not specified; if that is the case, internaly, hyper-paramters are set so that the prior modes are consistent with the variance partition specified by R2 and the prior distribution is relatively flat at the mode. For further details see the vignettes in the package or http://genomics.cimmyt.org/BGLR-extdoc.pdf.Defult 0.5
#' @param weights  (numeric, n) a vector of weights, may be NULL. If weights is not NULL, the residual variance of each data-point is set to be proportional to the square of the weight. Only used with Gaussian outcomes.
#' @param verbose  (logical) if TRUE the iteration history is printed, default FALSE.
#' @param rmExistingFiles  (logical) if TRUE removes existing output files from previous runs, default TRUE.
#' @param groups  (factor) a vector of the same length of y that associates observations with groups, each group will have an associated variance component for the error term.
#' 
#' @return  
#' a array of the result from RKHS
#' @author Chuang Ma  , Qian Cheng , Zhixu Qiu , Jie Song
#' @keywords RKHS, model predict
#' @export
#' @examples
#' \dontrun{
#' ## Load example data ##
#' data(GYSS)
#'
#' ## use RR model to modeling and predict ##
#' RKHS_Res <- RKHS.F2P(trainedMarkerMat = Markers, trainedPheVal = phenotype, 
#'                      predictMarkerMat = Markers[1:10,],nIter = 1500, burnIn = 500)
#' }

########################################### modeling and predicting RKHS ###########################################
RKHS.F2P <- function(trainedMarkerMat, trainedPheVal, predictMarkerMat, nIter = 7000, burnIn = 500, thin = 5,
                     saveAt = "", S0 = NULL, df0 =5, R2 = 0.5, weights = NULL,
                     verbose = FALSE, rmExistingFiles = TRUE, groups=NULL){
  numT <- nrow(predictMarkerMat)
  MarkerMat <- rbind(predictMarkerMat,trainedMarkerMat)
  pheVal <- c(rep(NA,numT),trainedPheVal)
  X <-scale(x = MarkerMat,center=TRUE,scale=TRUE)
  G <-tcrossprod(X)/ncol(X)
  
  RKHS.Fit <- BGLR(y=pheVal, ETA=list(list(K=G, model= "RKHS")),  nIter = nIter, burnIn = burnIn, thin = thin, 
                   saveAt = saveAt, S0 = S0, df0 = df0, R2 = R2, weights = weights,
                   verbose = verbose, rmExistingFiles = rmExistingFiles, groups = groups)
  predRes <- RKHS.Fit$yHat[1:numT]
  predRes
}
