##from plos one, 2015, A Ranking Approach to Genomic Selection
meanNDCGEvaluation <- function( realScores, predScores, topK = 10 ){
  resVec <- rep(0, topK )
  for( idx in 1:topK ){
    resVec[idx] <- NDCGEvaluation( realScores, predScores, topK = idx )
  }
  meanNDCG <- mean(resVec)
  names(meanNDCG ) <- paste0("meanNDCG","_top",topK)
  return (meanNDCG)
}

##from plos one, 2015, A Ranking Approach to Genomic Selection
NDCGEvaluation <- function( realScores, predScores, topK = 10){
  
  if( length(realScores) != length(predScores) ){
    stop("Error: different length between realScores and predScores")
  }
  if( length(realScores) < topK ) {
    stop("Error: too large topK")
  }
  
  scoreMat <- cbind(realScores,predScores)
  scoreMatSortbyPred <- scoreMat[order(scoreMat[,2],decreasing = TRUE),]
  scoreMatSortByReal <- scoreMat[order(scoreMat[,1],decreasing = TRUE),]
  
  DCG <- rep(0, topK)
  IDCG <- rep(0, topK)
  for(idx in 1:topK){
    DCG[idx] <-  scoreMatSortbyPred[idx,1]/log(idx+1,2)
    IDCG[idx] <- scoreMatSortByReal[idx,1]/log(idx+1,2)
  }
  
  NDCG <- sum(DCG)/sum(IDCG) 
  names(NDCG) <- paste0("NDCG","_top",topK)
  return(NDCG)
}

##evaluation method: pearson, spearman, kendall, MSE
corEvaluation <- function( realScores, predScores, method = c("pearson", "kendall", "spearman", "MSE","R2") ){
  
  if( length(method) > 1 ){
    method <- method[0]
  }
  checkMethodType <- method %in% c("pearson", "kendall", "spearman", "MSE","R2")
  if( !checkMethodType ){
    stop("Error: undefined method in corEvaluation")
  }
  
  
  realScores <- as.matrix(realScores)
  predScores <- as.matrix(predScores)
  res <- ""
  if( (method == "pearson") | (method == "kendall") | (method == "spearman") ){
    res <- cor( realScores, predScores,  use="complete", method = method  )
  }else if(method == "MSE") {
    res <- apply(predScores,2,function(ii){
      deltaVec <- abs( realScores - ii)
      deltaVec <- deltaVec^2
      mean(deltaVec)})
  }else if(method == "R2"){
    res <-apply(predScores,2,function(ii){
      R2 <- summary(lm(realScores ~ ii))$r.squared })
  }
  
  res <- matrix(res,nrow = 1,dimnames = list(method,colnames(predScores)))
  res
}

####
##function: RE and kappa from Heredity paper
## type:regression
##rank: top:(TRUE,TRUE); middle and down :(FALSE,FALSE)
##type: classfication
##rank: top:(TRUE,TRUE): middle and down :top:(FALSE,TRUE)
classEvaluation <- function(realScores, predScores, topAlpha = 15, Beta = 1,Probability = TRUE,evaMethod = "RE",BestIndividuals = c("top", "middle", "buttom") ) {

  #if( is.null( names(realScores)) ){
  #names(realScores) <- paste("sample", 1:length(realScores), sep = "")
  #}
  if( length(realScores) != length(predScores) ){
    stop("Error: different length between realScores and predScores")
  }
  
  if( length(BestIndividuals) > 1 ) {
    BestIndividuals <- BestIndividuals[1]
  }
  
  realScores <- as.numeric(realScores)
  predScores <- as.numeric(predScores)
  total <- length(realScores)
  topK <- round( total*topAlpha/100 )
  classVec <- c( rep(1, topK), rep(0, total-topK))
  
  decreaseReal <- TRUE
  decreasePred <- TRUE
  if(Probability == TRUE){
    if(BestIndividuals != "top")  {
      decreaseReal <- FALSE
      decreasePred <- FALSE
    }
  }else if (Probability == FALSE)  {
    if(BestIndividuals != "top") {
      decreaseReal <- FALSE
      decreasePred <- TRUE
      if(BestIndividuals == "middle") {
        realScores <- abs(realScores)
        predScores <- abs(predScores)
      }
    }
  }else {
    stop("Error: undefined model type")
  }
  
  scoreMat <- cbind( realScores, predScores )
  newScoreMat <- scoreMat[order(scoreMat[,1], decreasing = decreaseReal),] 
  newScoreMat <- cbind( newScoreMat, classVec )
  topRealMean <- mean( newScoreMat[1:topK,1] )
  
  ##### RE ,kappa
  newScoreMat <- newScoreMat[order(newScoreMat[,2], decreasing = decreasePred),]
  newScoreMat <- cbind( newScoreMat, classVec )
  colnames(newScoreMat) <- c("real", "predicted", "realClass", "predClass")
  PredRealMean <- mean( newScoreMat[1:topK,1] ) 
  
  TP <- sum( newScoreMat[1:topK, 3])
  FP <- topK - TP
  FN <- topK - TP
  TN <- total - topK - FN
  Po <- (TP+TN)/total
  Pe <- ((FP+TN)/total)*((FN+TN)/total) + ((TP+FN)/total)*((TP+FP)/total)
  allRealMean <- mean( scoreMat[,1] )
  precision = TP/(TP + FP)
  recall = TP/(TP +FN)
  ###  the area under the receiver operating characteristics curve(AUC),and  the area under the precision-recall  curve (AUCpr)
  result <- sapply(evaMethod,function(one_method){
    switch(one_method,
           Kappa =  (Po-Pe)/(1-Pe),
           RE = ( PredRealMean - allRealMean)/(topRealMean - allRealMean),
           auc = roc.curve(scores.class0 = newScoreMat[newScoreMat[,3] == 1,2],scores.class1 = newScoreMat[newScoreMat[,3] == 0,2],curve = TRUE)$auc ,
           AUCpr = pr.curve(scores.class0 = newScoreMat[newScoreMat[,3] == 1,2],scores.class1 = newScoreMat[newScoreMat[,3] == 0,2],curve = TRUE)$auc.integral,
           accuracy = (TP + TN)/total,
           F1 = (1 + Beta^2)*precision *recall/(precision + recall )
    )
  })
  names(result) <- paste(evaMethod,"_top", topAlpha, sep = "" )
  return(result) 
}

##################################### to evaluate for multiple parameters set
multiParameters <- function(realScores,predScores, Probability = TRUE,evaMethod = c("RE"),topAlpha ,Beta = 1,BestIndividuals = c("top")){
  
  ############ calculate one or multiple topAlpha 
  multiTopAlpha <- function(realScores,predScores, Probability ,evaMethod ,topAlpha,Beta,BestIndividuals){
    ######################### one or multiple topAlpha for classifiction evaluation
    if (length(intersect(evaMethod,c("RE", "Kappa", "auc","AUCpr","accuracy" ,"precision","recall","F1" ))) != 0){
      result <-  sapply(topAlpha,function(ii)
        classEvaluation(realScores = realScores,predScores = predScores,Probability = Probability,
                        evaMethod = evaMethod,topAlpha = ii,Beta = Beta,BestIndividuals = BestIndividuals)
      ) }
    
    ######################### one or multiple topAlpha for NDCG evaluation
    ################ set format of output #############
    if(length(evaMethod) > 1){
      result <- t(result)
    }else{
      result <- as.matrix(result)
    }
    dimnames(result) <- list(paste0("top",topAlpha),evaMethod )
    return(result)
  }
  
  
  predScores <- as.matrix(predScores)
  evalNum <- 1:ncol(predScores)
  
  ############ evaluate one or multiple prediction result
  multiPredresult <- lapply(evalNum,function(ii){
    multiTopAlpha(realScores = realScores,predScores = predScores[,ii],Probability = Probability,evaMethod = evaMethod ,topAlpha = topAlpha,Beta = Beta,BestIndividuals = BestIndividuals )
  })
  
  ######### set format of output
  result <- lapply(evaMethod,function(ii){
    one_evaMethod <- sapply(evalNum,function(jj) multiPredresult[[jj]][,ii])
    if(length(topAlpha) > 1){
      colnames(one_evaMethod) <- colnames(predScores)
    }else{
      one_evaMethod <- matrix(one_evaMethod,nrow = 1,dimnames = list(paste0("top",topAlpha),colnames(predScores)))
    }
    one_evaMethod
  })
  names(result) <- evaMethod
  return(result)
}


################################## evaluateGS ###################################



#' @title evaluateGS
#' @description  this function is used to evaluete the accuracy of predicted by genomic selection model.
#' @param realScores  A numeric vector is the real breeding values of the validation individual for a trait.
#' @param predScores  A numeric vector or matrix is the prediction breeding value predicted by genomic selection model of the individuals.
#' @param Probability  For RE and kappa method , whether the predScores is probability? Default True.
#' @param evaMethod  A character vetctor is the methods selected to evaluete, which include "pearson", "kendall", "spearman", "MSE","R2"
#' "RE", "Kappa", "auc","AUCpr","accuracy","F1","meanNDCGEvaluation", "NDCGEvaluation".
#' @param Beta the parameter of "F1"
#' @param BestIndividuals   It is a stratrgy that you want to select the best individuals in the candidate groups, according to the prediction breeding value of a trait,when using RE and kappa method.
#' if the trait was yield,flowering or disease resistance,and  male flowering time to female flowering time,it is "top"(default), "buttom",and "middle", respectively.
#' when the parameter is "top", the parameter Probability make no difference.
#' @param topAlpha  A numeric vector is the proportion of excellent individuals,defaulting 1:90.
#' @return 
#' a list inculding  evaluation results with methods which user selected.
#' 
#' @author Chuang Ma, Zhixu Qiu, Qian Cheng, Jie Song
#' @keywords evaluation, pearson, kendall, spearman, MSE, R2, RE, Kappa, auc, AUCpr, accuracy, F1, meanNDCGEvaluation, NDCGEvaluation
#' @export
#' @examples
#' \dontrun{
#' data(GYSS)
#' ########## predicting breeding value
#' predlist <-  G2P(cross = 10,seed = 1 ,cpus = 3,markers  = Markers,pheVal  = phenotype,
#'                  modelMethods = c("rrBLUP","RFC"),outputModel = FALSE)
#' predMartix <- NULL
#' for(ii in 1:10){predMartix <- rbind(predMartix,predlist[[ii]])}
#' ######## evaluate the accuracy of the prediction result
#'
#' evaluareTest <- evaluateGS(realScores = predMartix[,1], predScores = predMartix[,2:3], 
#'                            evaMethod = c("pearson", "kendall","spearman","RE","Kappa",
#'                                          "auc","AUCpr","NDCGEvaluation","meanNDCGEvaluation",
#'                                          "MSE","R2","F1","accuracy"),topAlpha = 1:90)
#' }

evaluateGS <- function(realScores, predScores, Probability = TRUE, evaMethod = "RE", Beta = 1, BestIndividuals = "top", topAlpha = 1:90){
  selectFun <- NULL
  predScores <- as.matrix(predScores)
  corMethods <-  c("pearson", "kendall", "spearman", "MSE","R2")
  classMethods <- c("RE", "Kappa", "auc","AUCpr","accuracy" ,"precision","recall","F1" )
  NDCGMethods <- c("meanNDCGEvaluation", "NDCGEvaluation")
  ###################### correlation methods
  if (length(intersect(evaMethod,corMethods)) != 0){
    selectFun <- c(selectFun,"corEvaluation")
    corMethods  <- intersect(evaMethod,corMethods)
  }
  
  ################# classifiction evaluation
  if (length(intersect(evaMethod,classMethods)) != 0){
    selectFun <- c(selectFun,"classEvaluation")
    classMethods <- intersect(evaMethod,classMethods)
  }
  #################### NDCG evaluation
  #  if (length(intersect(evaMethod,NDCGMethods)) != 0){
  #    selectFun <- c(selectFun,intersect(evaMethod,NDCGMethods))
  #    topK <- topAlpha
  #  }
  result <- lapply(selectFun,function(one_fun){
    switch(one_fun,corEvaluation = { corResult <- sapply(corMethods,function(one_methods){corEvaluation( realScores, predScores, method = one_methods)});
    matrix(t(corResult),ncol= ncol(predScores),dimnames = list(corMethods,colnames(predScores)))},
    classEvaluation = multiParameters(realScores, predScores, topAlpha = topAlpha, Probability = Probability,evaMethod = classMethods,Beta =Beta , BestIndividuals = BestIndividuals ) 
    
    )})
  
  ############ the format of output
  finalresult <- list()
  id <- 1
  if(!is.list(result[[1]])){
    finalresult[["corMethosds"]] <- result[[1]]
    id <- 2
  }
  for(ii in id:length(result)){
    finalresult <- c(finalresult,result[[ii]])
  }
  
  if (length(intersect(evaMethod,c("meanNDCGEvaluation", "NDCGEvaluation"))) != 0){
    ndcgFun <- intersect(c("meanNDCGEvaluation","NDCGEvaluation"),evaMethod)
    
    if(length(ndcgFun) > 1){
      M1 <- t(matrix(1:length(topAlpha),1))
      for(i in 1:ncol(predScores)){
        res <- NDCG(method = "meanNDCGEvaluation",topAlpha = topAlpha,realScores= realScores,predScores = predScores[,i])
        M1 <- cbind(M1,as.matrix(res))
      }
      M1 <- M1[,-1]
      colnames(M1) <- colnames(predScores)
      
      M2 <- t(matrix(1:round(length(realScores)*(max(topAlpha)/100)),1))
      for(i in 1:ncol(predScores)){
        res <- NDCG(method = "NDCGEvaluation",topAlpha = topAlpha,realScores= realScores,predScores = predScores[,i])
        M2 <- cbind(M2,as.matrix(res))
      }
      M2 <- M2[,-1]
      colnames(M2) <- colnames(predScores)
      M <- list(NDCGEvaluation = M2,meanNDCGEvaluation = M1)
    }else{
      if (ndcgFun == "meanNDCGEvaluation"){
        M <- t(matrix(1:length(topAlpha),1))
        for(i in 1:ncol(predScores)){
          res <- NDCG(method = "meanNDCGEvaluation",topAlpha = topAlpha,realScores= realScores,predScores = predScores[,i])
          M <- cbind(M,as.matrix(res))
        }
        M <- M[,-1]
        colnames(M) <- colnames(predScores)
        M <- list(meanNDCGEvaluation = M)
      }else{
        M <- t(matrix(1:round(length(realScores)*(max(topAlpha)/100)),1))
        for(i in 1:ncol(predScores)){
          res <- NDCG(method = "NDCGEvaluation",topAlpha = topAlpha,realScores= realScores,predScores = predScores[,i])
          M <- cbind(M,as.matrix(res))
        }
        M <- M[,-1]
        colnames(M) <- colnames(predScores)
        M <- list(NDCGEvaluation = M)
      }
    }
    finalresult <- c(finalresult,M)
  }
  finalresult
}

NDCG <- function(method = NULL,topAlpha,realScores,predScores){
  ndcg <- 1 : round(length(realScores)*(max(topAlpha)/100))
  
  if(method == "NDCGEvaluation"){
    result <- sapply(ndcg,function(ii){
      NDCGEvaluation(realScores = realScores,predScores = predScores,topK = ii)
    })
  }else if(method == "meanNDCGEvaluation"){
    result <-  sapply(topAlpha,function(ii){
      iii <- round(ii*length(realScores)/100)
      meanNDCGEvaluation(realScores = realScores,predScores = predScores,topK = iii)
    })
    names(result) <- paste0("meanNDCG_top",topAlpha)
  }
  result
}
