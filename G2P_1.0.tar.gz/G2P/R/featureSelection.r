############################## Feature Selection ############################

#' @title Feature Selection
#' @description  This function score each SNP set, you can screen of high grade of SNP for subsequent modeling, in order to simplify the operation and improve the precision of feature selection.(methods including Gini,  Accuracy, rrBLUP)
#' @param markers  a numeric matrix, each row is the each individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represent AA(homozygote),2 represent BB(homozygote) and 1 represent AB(heterozygote);missing (NA) alleles are not allowed.
#' @param pheVal  the phenotype Value of each individual(numeric)
#' @param method  the method of feature selction including "Gini" "Accuracy" "rrBLUP"
#' @param ntree  the number of random forest decision tree,defult 500
#' @param importance  whether the results of variable importance,defult TRUE
#' @param posPercentage  phenotypic good proportion in Classification,defult 0.4
#' @param BestIndividuals the better phenotype position including "top","buttom",defult "top"
#' @return
#' ## Not run:
#' A numeric mode score of each position of SNPs
#' 
#' @author Chuang Ma , Zhixu Qiu , Qian Cheng ,Jie Song
#' @keywords feature selction,Gini,Accuracy,rrBLUP
#' @export
#' @examples
#' \dontrun{
#' data(GYSS)
#' ## feature selection with Gini ##
#' Gini_selection <- feature_assess(markers = Markers, pheVal = phenotype, method = "Gini", 
#'                                  ntree = 500, importance = TRUE, posPercentage = 0.40,
#'                                  BestIndividuals = "top")
#'
#' ## feature selection with Acc ##
#' Acc_selection <- feature_assess(markers = Markers, pheVal = phenotype, method = "Accuracy", 
#'                                 ntree = 500, importance = TRUE, posPercentage = 0.40,
#'                                 BestIndividuals = "top")
#'
#' ## feature selection with rrBLUP ##
#' rrBLUP_selection <- feature_assess(markers = Markers, pheVal = phenotype, method = "rrBLUP", 
#'                                    posPercentage = 0.40, BestIndividuals = "top")
#' }





##SNP feature order Gini Accuracy rrBLUP

feature_assess <- function(markers, pheVal, method = c("rrBLUP", "Gini", "Accuracy"), ntree = 500, importance = TRUE, posPercentage = 0.40, BestIndividuals = c("top", "middle", "buttom")){
  if(length(method) > 1){
    method = "rrBLUP"
  }
  if(length(BestIndividuals > 1)){
    BestIndividuals <- "top"
  }
  posNegSampleList <- sampleClassify(pheVal = pheVal, posPercentage = posPercentage, BestIndividuals = BestIndividuals )
  Xtrain <- markers[c(posNegSampleList$posSampleIndex,posNegSampleList$negSampleIndex),]
  YClasif <-  as.factor( c( rep("1", length(posNegSampleList$posSampleIndex)), rep("0", length(posNegSampleList$negSampleIndex)) ) )
  switch(method,
         rrBLUP = trainModel_RRBLUP( markers , pheVal  )$phD,
         Accuracy =  randomForest( x = Xtrain, y = YClasif, ntree = ntree, importance = importance)$importance[,"MeanDecreaseAccuracy"],
         Gini = randomForest( x = Xtrain, y = YClasif, ntree = ntree, importance = importance)$importance[,"MeanDecreaseGini"]
  )
}






 
