plotPCA  <- function(markers,centers = 4){
  requireNamespace("rgl", quietly = TRUE)
  PCA_Marker <- prcomp( markers)
  ############ kmean for cluster
  cluster.PCA <- kmeans(PCA_Marker$x[,1:2],centers = centers,iter.max = 50,nstart = 1,algorithm = "Forgy")
  rgl::plot3d(PCA_Marker$x[,1:3],col = cluster.PCA$cluster,size = 5)
}


plotEvalue <- function(plotMartix,plotType = c("graph"),centers = 4,colorSet = rainbow(ncol(plotMartix)),main = NULL,ylab = "Relative efficiency",
                       legend.name = colnames(plotMartix)){
  ########################## plot graph #######################
  requireNamespace("pheatmap", quietly = TRUE)
  if(plotType == "graph"){
    nrowNum <- nrow(plotMartix)
    a <- nrowNum
    b <- round(nrowNum/10)
    legendN <- legend.name
    xlabels <- seq(0,a,b)
    xlabeln <- seq(0,a,b)
    if(nrowNum > 99){
      xlabx <- expression(paste("top ",n,sep = ""))
    }else{
      xlabx <- expression(paste("top ",alpha,"(%)",sep = ""))
    }
    ##############
    if(min(plotMartix) > 0.5){
      ylimR <- c(0.5,max(plotMartix)+0.1)
    }else {
      ylimR <- c(0,max(plotMartix)+0.1)
    }
    #############
    plot(x = 1:nrowNum,y = 1:nrowNum,ylim = ylimR,ylab = ylab,main = main,xlab =  xlabx,type = "n",xaxt ="n")
    sapply(1:ncol(plotMartix),function(jj) {points(plotMartix[,jj],col = colorSet[jj],type="l",lwd = 3 )})
    axis(1,at = xlabels ,labels = xlabeln,las = 0)
    legend(x=2,y= max(plotMartix)+0.1 ,col= colorSet,legend = legendN ,lty=1,horiz = T,
           lwd = 2,cex = 0.8,bty = "n")
  }
  ##############################################################################################
  ######################### plot heatmap#########################
  if(plotType == "heatmap"){
    colorSet <- colorRampPalette(c("green","black","red"))(50) 
    pheatmap::pheatmap(plotMartix, cluster_rows = F,cluster_cols = F,cellwidth = 10,color = colorSet,fontsize = 10,show_rownames = FALSE  ,legend= TRUE)
  }
}


###############
########################## exhibit evaluation result and data structure###########################

#' @title Exhibit evaluation result and data structure 
#' @description exhibit evaluation result and data structure from genomic selection.
#' @param markers  the marker data for genomic selection.
#' @param plotMartix  numeric matrix of the values to be plotted,which is given from evaluating result.
#' @param centers  either the number of clusters, say k, or a set of initial (distinct) cluster centres. If a number, a random set of (distinct) rows in x is chosen as the initial centres.
#' @param plotType  the type of plot is including "population_structure" of markers and "graph" and "heatmap " of evaluate value.
#' @param colorSet  vector of colors used to plot "graph".
#' @param main  the title of the plot.
#' @param ylab  a title for the y axis.
#' @param legend.name  a character or expression vector of length >= 1 to appear in the legend,used to  plolt graph
#' @return  
#' a plot of result
#' @export 
#' @author Chuang Ma, Qian Cheng, Zhixu Qiu, Jie Song
#' @keywords plot,result exhibit
#' @examples 
#' \dontrun{
#' ############# PCA analysis ############
#' data(GYSS)
#' result_diplay(markers = Markers,centers = 4,plotType = c("population_structure"))
#' 
#' ############# GS evaluation results disply ##############
#' predlist <-  G2P(cross = 10, seed = 1, cpus = 3, markers = Markers,
#'                  pheVal = phenotype, modelMethods = c("rrBLUP","RFC"), outputModel = FALSE)
#' predMartix <- NULL
#' for(ii in 1:10){predMartix <- rbind(predMartix, predlist[[ii]])}
#' ######## evaluate the accuracy of the prediction result
#' evaluareTest <- evaluateGS(realScores = predMartix[,1],predScores = predMartix[,2:3],
#'                            evaMethod = c("pearson", "kendall", "spearman", "RE",
#'                            "NDCGEvaluation", "meanNDCGEvaluation"), topAlpha = 1:90)
#' ########## exhibit the evaluation value ###########
#' REMat <- evaluareTest$RE
#' result_diplay(plotMartix = REMat, plotType = "graph", main = "RE", ylab = "Relative efficiency")
#' }

result_diplay <- function(markers, plotMartix, centers = 4, plotType = c("population_structure"), colorSet = rainbow(ncol(plotMartix)), main = NULL, ylab = "Relative efficiency",
                          legend.name = colnames(plotMartix)){
  switch(plotType,
         population_structure = plotPCA(markers = markers,centers = centers),
         graph = plotEvalue(plotMartix = plotMartix ,plotType = "graph",main = main,ylab = ylab,legend.name = legend.name),
         heatmap = plotEvalue(plotMartix = plotMartix ,plotType ="heatmap"))
}
