

############################################################# parallel ###########################################################################



one_GS <- function(trainMarker,trainPheno,testMarker,testPheno,modelMethods ="SVC",outputModel = FALSE,  # main parameters
                   nIter = 7000, burnIn = 500, thin = 5, 
                   saveAt = "", S0 = NULL, df0 =5, R2 = 0.5, weights = NULL,
                   verbose = FALSE, rmExistingFiles = TRUE, groups=NULL,importance = FALSE,    # # # BGLR method parameters
                   posPercentage = 0.4,BestIndividuals = c("top"),ntree = 500,nodesize = 1,kernel = c("linear"),gamma = 1, cost = 2^(-9),  # machine learing parameters
                   K = 8,eta = 0.7,select = "pls2",fit = "simples",scale.x = FALSE,scale.y = FALSE,eps = 1e-4,trace = FALSE, # SPLS parameters
                   alpha = 1,...){   # LASSO parameters
  
  GSReMethods <- c("BayesA", "BayesB", "BayesC", "BL", "BRR", "RKHS","rrBLUP","LASSO","SPLS") 
  MachineMethods <- c("SVC","RFC","SVR","RFR")
  NamesMethods <- NULL
  
  ########################## building regessoion model for GS
  if (length(intersect(modelMethods,GSReMethods)) != 0){
    GSReMethods  <- intersect(modelMethods,GSReMethods)
    NamesMethods <- GSReMethods 
    trainedModelList <- lapply(GSReMethods,function(ii){GSReModel(modelMethods = ii,markers = trainMarker,pheVal = trainPheno ,nIter = nIter, burnIn = burnIn, thin = thin, 
                                                                  saveAt = saveAt, S0 = S0, df0 =df0, R2 = R2, weights = weights,
                                                                  verbose = verbose, rmExistingFiles = rmExistingFiles, groups=groups,
                                                                  K = K,eta = eta,select = select,fit = fit,scale.x = scale.x,scale.y = scale.y,eps = eps,trace = trace,
                                                                  alpha = alpha,...)})
  }else{
    GSReMethods <- NULL
    trainedModelList <- NULL
  }
  
  ###############################3  building  machine model for GS
  if (length(intersect(modelMethods,MachineMethods)) != 0){
    MachineMethods <- intersect(modelMethods,MachineMethods)
    NamesMethods <- c(GSReMethods,MachineMethods)
    machinemodel <- lapply(MachineMethods,function(ii){GSmachine(markers = trainMarker,pheVal = trainPheno,posPercentage = posPercentage ,BestIndividuals = BestIndividuals,
                                                                 modelMethods = ii ,ntree = ntree ,nodesize = nodesize,
                                                                 kernel = kernel,gamma = gamma, cost = cost)})
    trainedModelList <- c(trainedModelList,machinemodel)
    
  }
  names(trainedModelList) <- NamesMethods
  
  
  ######### predict breeding value of test sample
  predscores <- sapply(NamesMethods,function(ii){predictGS(testMat = testMarker,trainModel = trainedModelList[[ii]],modelMethods = ii )})
  predscores <- cbind(testPheno,predscores)
  colnames(predscores)[1] <- "realPhenScore"
  result <- list()
  
  
  ####### output result
  if(outputModel){
    result[["trainModel"]] <- trainedModelList
    result[["predscores"]] <- predscores 
    rm(trainMarker,testMarker)
    return(result)
  }
  else{
    return(predscores)
  }
}

one_cross_validation_GS <- function(cvSampleList,markers,pheVal,modelMethods ="SVC",outputModel = FALSE,
                                    nIter = 7000, burnIn = 500, thin = 5, 
                                    saveAt = "", S0 = NULL, df0 =5, R2 = 0.5, weights = NULL,
                                    verbose = FALSE, rmExistingFiles = TRUE, groups=NULL,importance = FALSE,
                                    posPercentage = 0.4,BestIndividuals = c("top"),ntree = 500,nodesize = 1,kernel = c("linear"),gamma = 1, cost = 2^(-9),
                                    K = 8,eta = 0.7,select = "pls2",fit = "simples",scale.x = FALSE,scale.y = FALSE,eps = 1e-4,trace = FALSE, # SPLS parameters
                                    alpha = 1,...){
  ########### set training data and testing data
  trainIdx <- cvSampleList$trainIdx
  testIdx <-  cvSampleList$testIdx
  trainMarker <- markers[trainIdx,]
  trainPheno <- pheVal[trainIdx]
  testMarker <- markers[testIdx,]
  testPheno <- pheVal[testIdx]
  ####
  ##################  add of feature selection
  ############## 
  
  ################  run GS
  one_GS(trainMarker = trainMarker,trainPheno = trainPheno,testMarker = testMarker,testPheno =testPheno ,modelMethods = modelMethods ,BestIndividuals = BestIndividuals,
         nIter = nIter, burnIn = burnIn, thin = thin,  saveAt = saveAt, S0 = S0, df0 =df0, R2 = R2, weights = weights,posPercentage = posPercentage,
         verbose = verbose, rmExistingFiles = rmExistingFiles, groups=groups,ntree = ntree  ,nodesize = nodesize ,importance = importance,
         kernel = kernel,gamma = gamma, cost = cost,outputModel = outputModel,
         K = K,eta = eta,select = select,fit = fit,scale.x = scale.x,scale.y = scale.y,eps = eps,trace = trace,
         alpha = alpha,...)
}


##################################### cross validation for genomic selection  ####################################


#' @title G2P
#' @description  this function is apply cross validation to test Genomic Selection model trained by different methods and datas.
#' @param cross  (numeric)the fold number of cross validation.
#' @param seed  (numeric)random number options,defult 1.
#' @param cpus  (numeric)number of cpu cores to be used for calculations.
#' @param markers  (numeric) a matrix, each row is the each individual's SNP genotypes informations.Genotypes should be coded as {0,1,2};0 represents AA(homozygote),2 represents BB(homozygote) and 1 represents AB(heterozygote);missing (NA) alleles are not allowed
#' @param pheVal  (numeric)the phenotype Value of each individual.
#' @param modelMethods  the model to fit."BayesA", "BayesB", "BayesC", "BL", "BRR","RKHS","rrBLUP","LASSO","SPLS","SVC","SVR","RFR","RFC"
#' @param nIter,burnIn,thin  (integer) the number of iterations, burn-in and thinning,default nIter 7000,burnIn 500,thin 5.
#' @param saveAt  (string) this may include a path and a pre-fix that will be added to the name of the files that are saved as the program runs,default ""
#' @param S0,df0  (numeric) The scale parameter for the scaled inverse-chi squared prior assigned to the residual variance, only used with Gaussian outcomes. In the parameterization of the scaled-inverse chi square in BGLR the expected values is S0/(df0-2). The default value for the df parameter is 5. If the scale is not specified a value is calculated so that the prior mode of the residual variance equals var(y)*R2 (see below). For further details see the vignettes in the package or http://genomics.cimmyt.org/BGLR-extdoc.pdf.Default S0 NULL,df0 5.
#' @param R2  (numeric, 0<R2<1) The proportion of variance that one expects, a priori, to be explained by the regression. Only used if the hyper-parameters are not specified; if that is the case, internaly, hyper-paramters are set so that the prior modes are consistent with the variance partition specified by R2 and the prior distribution is relatively flat at the mode. For further details see the vignettes in the package or http://genomics.cimmyt.org/BGLR-extdoc.pdf.Defult 0.5
#' @param weights  (numeric, n) a vector of weights, may be NULL. If weights is not NULL, the residual variance of each data-point is set to be proportional to the square of the weight. Only used with Gaussian outcomes.
#' @param verbose  (logical) if TRUE the iteration history is printed, default FALSE
#' @param rmExistingFiles  (logical) if TRUE removes existing output files from previous runs, default TRUE.
#' @param groups  (factor) a vector of the same length of y that associates observations with groups, each group will have an associated variance component for the error term.
#' @param ntree  RandomForest parameter:Number of trees to grow. This should not be set to too small a number, to ensure that every input row gets predicted at least a few times.Defualt 500
#' @param nodesize Randomforest parameter Minimum size of terminal nodes. Setting this number larger causes smaller trees to be grown (and thus take less time). Note that the default values are different for classification (1) and regression (5).
#' @param importance  RandomForest parameter:Should importance of predictors be assessed?Defualt FALSE
#' @param posPercentage  (numeric)the percentage positive samples in all samples.1 > posPercentage > 0.
#' @param BestIndividuals  It is a position that the best individuals (positive samples) in a training group, according to the breeding values of a training group's trait.
#'                          if the trait was yield,flowering or disease resistance,and  male flowering time to female flowering time,it is "top"(default), "buttom",and "middle" of the breeding values, respectively.
#' @param kernel  svm parameter the kernel used in training and predicting. You might consider changing some of the following parameters, depending on the kernel type.(linear,polynomial,sigmoid,radial)Default "linear".
#' @param gamma  svm parameter parameter needed for all kernels except linear (default: 1/(data dimension))
#' @param cost  svm cost,default 2^(-9)
#' @param outputModel  if true return the list of training model.
#' @param K  Number of hidden components
#' @param eta	 Thresholding parameter. eta should be between 0 and 1.
#' @param select  PLS algorithm for variable selection. Alternatives are "pls2" or "simpls". Default is "pls2"
#' @param fit	 PLS algorithm for model fitting. Alternatives are "kernelpls", "widekernelpls", "simpls", or "oscorespls". Default is "simpls".
#' @param scale.x	 Scale predictors by dividing each predictor variable by its sample standard deviation?
#' @param scale.y  Scale responses by dividing each response variable by its sample standard deviation?
#' @param eps  An effective zero. Default is 1e-4
#' @param maxstep  Maximum number of iterations when fitting direction vectors. Default is 100.
#' @param trace  Print out the progress of variable selection?
#' @param alpha  The elasticnet mixing parameter, with 0≤α≤ 1.Detail in glmnet.
#' @param ...  arguments passed to or from other methods.
#' @return 
#' a list:
#' The prediction results of input GS method with cross validation.
#' 
#' @author Chuang Ma ,Qian Cheng , Zhixu Qiu ,Jie Song
#' @keywords cross validation,Genomic Selection
#' @export
#' @examples
#' \dontrun{
#' data(GYSS)
#' ########## predicting breeding value
#' predlist <- G2P(cross = 10,seed = 1 , cpus = 3, markers = Markers,
#'                 pheVal = phenotype, modelMethods = c("rrBLUP", "RFC"),
#'                 outputModel = FALSE)
#' }

G2P <- function(cross = 5, seed = 1, cpus = 1, markers, pheVal, modelMethods ="SVC", outputModel = FALSE,
                nIter = 7000, burnIn = 500, thin = 5, 
                saveAt = "", S0 = NULL, df0 =5, R2 = 0.5, weights = NULL,
                verbose = FALSE, rmExistingFiles = TRUE, groups=NULL, importance = FALSE,
                posPercentage = 0.4, BestIndividuals = c("top"), ntree = 500, nodesize = 1, kernel = c("linear"), gamma = 1, cost = 2^(-9),
                K = 8, eta = 0.7, select = "pls2", fit = "simples", scale.x = FALSE, scale.y = FALSE, eps = 1e-4, trace = FALSE, maxstep = 100,  # SPLS parameters
                alpha = 1,...){
  
  cvSampleList <- cvSampleIndex(sampleNum = length(pheVal),cross = cross,seed = seed)
  
  sfInit(parallel = TRUE, cpus = cpus) 
  sfLibrary( "brnn", character.only=TRUE)
  sfLibrary( "glmnet", character.only=TRUE)
  sfLibrary( "spls", character.only=TRUE)
  sfLibrary( "pls", character.only=TRUE)
  sfLibrary( "e1071", character.only=TRUE)
  sfLibrary( "BGLR", character.only=TRUE)
  sfLibrary( "rrBLUP", character.only=TRUE)
  sfLibrary( "randomForest", character.only=TRUE)
  sfLibrary( "G2P", character.only=TRUE)
  #sfExport("one_GS")
  #sfExport("one_cross_validation_GS")
  #sfExport("GSReModel")
  #sfExport("trainedPredictModel_BGLR")
  #sfExport("trainModel_RRBLUP")
  #sfExport("GSmachine")
  #sfExport("sampleClassify")
  #sfExport("predictGS")
  cvresult <- sfClusterApplyLB(cvSampleList,one_cross_validation_GS, markers = markers,pheVal = pheVal,modelMethods = modelMethods ,BestIndividuals = BestIndividuals,
                               nIter = nIter, burnIn = burnIn, thin = thin,  saveAt = saveAt, S0 = S0, df0 =df0, R2 = R2, weights = weights,posPercentage = posPercentage,
                               verbose = verbose, rmExistingFiles = rmExistingFiles, groups=groups,ntree = ntree ,nodesize = nodesize ,importance = importance,
                               kernel = kernel,gamma = gamma, cost = cost,outputModel = outputModel,
                               K = K,eta = eta,select = select,fit = fit,scale.x = scale.x,scale.y = scale.y,eps = eps,trace = trace,maxstep = maxstep,
                               alpha = alpha,...)
  sfStop()
  
  task_names <- paste0("cv",1:cross)
  names(cvresult) <- task_names 
  if(outputModel){
    modelList <- lapply(task_names,function(cv) cvresult[[cv]]$trainModel)
    predscores <- lapply(task_names,function(cv) cvresult[[cv]]$predscores)
    names(modelList) <- task_names 
    names(predscores ) <- task_names
    cvresult <- list(modelList,predscores)
    names(cvresult) <- c("modelList","predscores")
    return(cvresult)
    
  }else{
    predscores <- lapply(task_names,function(cv) cvresult[[cv]])
    names(predscores ) <- task_names
    return(predscores)
  }
  
}







